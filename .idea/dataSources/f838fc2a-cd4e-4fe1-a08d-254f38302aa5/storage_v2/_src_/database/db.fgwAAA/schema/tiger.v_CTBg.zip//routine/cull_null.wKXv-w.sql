create function cull_null(character varying) returns character varying
    immutable
    language sql
as
$$
    SELECT coalesce($1,'');
$$;

alter function cull_null(varchar) owner to "user";

