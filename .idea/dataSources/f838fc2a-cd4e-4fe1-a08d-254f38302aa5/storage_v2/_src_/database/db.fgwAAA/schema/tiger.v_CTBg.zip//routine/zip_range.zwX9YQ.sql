create function zip_range(zip text, range_start integer, range_end integer) returns character varying[]
    immutable
    strict
    parallel safe
    language sql
as
$$
   SELECT ARRAY(
        SELECT lpad((to_number( CASE WHEN trim(substring($1,1,5)) ~ '^[0-9]+$' THEN $1 ELSE '0' END,'99999')::integer + i)::text, 5, '0')::varchar
        FROM generate_series($2, $3) As i );
$$;

alter function zip_range(text, integer, integer) owner to "user";

