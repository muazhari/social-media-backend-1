create function asgml(tg topogeometry) returns text
    stable
    language sql
as
$$
 SELECT topology.AsGML($1, 'gml');
$$;

alter function asgml(topogeometry) owner to "user";

