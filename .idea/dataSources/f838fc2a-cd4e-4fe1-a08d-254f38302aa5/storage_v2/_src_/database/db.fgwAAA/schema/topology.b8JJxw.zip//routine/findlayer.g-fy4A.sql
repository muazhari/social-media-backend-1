create function findlayer(tg topogeometry) returns layer
    language sql
as
$$
    SELECT * FROM topology.layer
    WHERE topology_id = topology_id($1)
    AND layer_id = layer_id($1)
$$;

alter function findlayer(topogeometry) owner to "user";

