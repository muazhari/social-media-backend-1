create function findlayer(schema_name name, table_name name, feature_column name) returns layer
    language sql
as
$$
    SELECT * FROM topology.layer
    WHERE schema_name = $1
    AND table_name = $2
    AND feature_column = $3;
$$;

alter function findlayer(name, name, name) owner to "user";

