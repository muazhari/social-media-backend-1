create function findtopology(text) returns topology
    language sql
as
$$
    SELECT *
    FROM topology.topology
    WHERE name = $1
$$;

alter function findtopology(text) owner to "user";

