create function findtopology(topogeometry) returns topology
    language sql
as
$$
    SELECT * FROM topology.topology
    WHERE id = topology_id($1);
$$;

alter function findtopology(topogeometry) owner to "user";

