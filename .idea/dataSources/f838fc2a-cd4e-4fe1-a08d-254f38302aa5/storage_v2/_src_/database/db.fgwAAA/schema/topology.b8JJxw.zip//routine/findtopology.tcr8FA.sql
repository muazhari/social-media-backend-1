create function findtopology(integer) returns topology
    language sql
as
$$
    SELECT *
    FROM topology.topology
    WHERE id = $1
$$;

alter function findtopology(integer) owner to "user";

