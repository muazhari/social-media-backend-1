create function postgis_topology_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.5.2'::text || $rev$ dea6d0a $rev$) AS version $$;

alter function postgis_topology_scripts_installed() owner to "user";

