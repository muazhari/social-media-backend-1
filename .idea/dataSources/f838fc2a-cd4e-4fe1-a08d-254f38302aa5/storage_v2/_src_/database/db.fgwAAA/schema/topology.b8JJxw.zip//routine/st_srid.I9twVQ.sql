create function st_srid(tg topogeometry) returns integer
    strict
    language sql
as
$$
	SELECT srid FROM topology.topology
  WHERE id = topology_id(tg);
$$;

alter function st_srid(topogeometry) owner to "user";

