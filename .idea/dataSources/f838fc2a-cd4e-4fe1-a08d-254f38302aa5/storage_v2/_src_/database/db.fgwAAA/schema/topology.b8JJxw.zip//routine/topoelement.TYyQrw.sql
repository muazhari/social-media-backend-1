create function topoelement(topo topogeometry) returns topoelement
    immutable
    parallel safe
    cost 1
    language sql
as
$$SELECT ARRAY[topo.id,topo.layer_id]::topology.topoelement;$$;

alter function topoelement(topogeometry) owner to "user";

